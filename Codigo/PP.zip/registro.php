<?php
    $direccion = "localhost";
	$nombreBADA = "abajova";
	$usuario = "root";
	$psw = "";

    $enlace= mysqli_connect($direccion,$usuario,$psw,$nombreBADA);

	$password= htmlspecialchars($_POST['contraseña']);
	$nomUsr= htmlspecialchars($_POST['username']);
	$name = htmlspecialchars($_POST['nombre']);
	$telefono = htmlspecialchars($_POST['telefono']);
	$apellido = htmlspecialchars($_POST['apellido']);

	$insertarDato = "INSERT INTO usuarios (usuario, contraseña, telefono, nombre, apellido) VALUES ('$nomUsr', '$password', '$telefono', '$name', '$apellido');";

	$insertarDatoBADA= mysqli_query($enlace, $insertarDato);

	if ( mysqli_connect_errno() ){
		echo "hubo error";
	}else {
		echo '<script>window.location.href="login.html";</script>';
	} 

?>
