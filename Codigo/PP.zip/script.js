async function fetchProducts() {
    try {
      const response = await fetch('http://localhost/productos.php');
      const products = await response.json();
      displayProducts(products);
    } catch (error) {
      console.error('Error al obtener productos:', error);
    }
  }

// Función para mostrar los productos
function displayProducts(products) {
    const productContainer = document.getElementById('product-container');
    productContainer.innerHTML = products.map((product, index) => createProductTemplate2(product, index)).join('');
}

function createProductTemplate2(product, index) {
    return `
      <div class="product">
        <img src="${product.imageUrl}"> 
        <div class="product-info">
          <h2>${product.name}</h2>
          <p>${product.description}</p>
          <p><strong>$${product.price}</strong></p>
          <button onclick="addToCart(${product.id})">Agregar al carrito</button>
        </div>
      </div>
    `;
}

function addToCart() {
    // Obtener los productos actualmente en el carrito desde el localStorage
    let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

    // Verificar si el producto ya está en el carrito
    const productoExistente = carrito.find(producto => producto.id === productoId);

    if (productoExistente) {
        // Si el producto ya está en el carrito, aumentar la cantidad
        productoExistente.cantidad++;
    } else {
        // Si el producto no está en el carrito, agregarlo
        carrito.push({
            id: product.id,
            cantidad: 1
        });
    }

    // Guardar el carrito actualizado en el localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));

}
// Llamar a la función al cargar la página
document.addEventListener('DOMContentLoaded', fetchProducts);
