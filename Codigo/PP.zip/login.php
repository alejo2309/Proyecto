<?php

$direccion = "localhost";
$nombreBADA = "abajova";
$usuario = "root";
$psw = "";

$enlace= mysqli_connect($direccion,$usuario,$psw,$nombreBADA);
$confirmacionLogin = false;
$username = $_POST['username'];
$password = $_POST['password'];
$consulta = "SELECT * FROM usuarios WHERE usuario='$username' and contraseña='$password'";
$login = mysqli_query($enlace, $consulta);

if (mysqli_num_rows($login) > 0) {
    echo '<script>window.location.href="index.html";</script>';
} else {
    echo "no";
}


?> 